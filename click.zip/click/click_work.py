import time

import pyautogui

# 限定搜索区域 (left, top, width, height)701,240 820,1034
region = (500, 250, 100, 786)

time.sleep(3)
# 找所有匹配
matches = pyautogui.locateAllOnScreen('./img/t4.png', region=region, confidence=0.8)
# x,y = pyautogui.locateCenterOnScreen('./img/t4.png', confidence=0.8)

# 转成列表（很重要，不然是生成器）
# print(list(matches))
matches = list(matches)
# for match in matches:
#     center = pyautogui.center(match)
#     pyautogui.moveTo(center.x, center.y, 0.5)
#     print(center) # 输出中心点坐标 (x, y)
#     time.sleep(1)
for box in matches:
    # pyautogui.moveTo(box.left,box.top,0.5)
    # time.sleep(1)
    if box.left >
    print(box.left,box.top)
is_duplicate = False

for px, py in points:
    if abs(x - px) < 10 and abs(y - py) < 10:
        is_duplicate = True
        break

if not is_duplicate:
    points.append((x, y))